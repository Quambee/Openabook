/******************************************/
  ************* README *******************
/******************************************/

Voici mon application de gestion d'une biblioth�que scolaire.
Elle permet de g�rer une partie administration et une partie pour les �l�ves.

Pour se connecter � l'administration:
mail: mickael.zimmermann@gmail.com
password: A1b2�$C3d4

Mail et mot de passe administration resteront identiques.
Il est possible de cr�er une cat�gorie de livres, des auteurs avec v�rification des champs.
Ensuite, possibilit� d'ajouter des livres par nom, cat�gorie et auteur.

Impossibilit� de supprimer un auteur ou une cat�gorie si un livre utilise l'un ou l'autre.
Impossibilit� de supprimer un livre s'il est an pr�t.


Partie �tudiant:

2 comptes d�j� cr��s:

mail: mickael.zimmermann@gmail.com	
password: abcd1234

mail: benoit.petit@gmail.com
password: abcd1234

mail: antoine.perrin@gmail.com
password: abcd1234

Possibilit� qu'un nouvel �l�ve s'inscrive.
Puis il peut se connecter et emprunter un livre.

Une liste de livres appara�t et permet de commander un livre s'il n'est pas d�j� emprunt� par quelqu'un d'autre.
Puis acc�s � la partie retour avec la date de retour pr�vu pour le livre.

La base est � cr�er avec le fichier "library.sql".


/* ATTENTION */
Lors de la cr�ation d'un �l�ve, il ne faut pas mettre de majuscule dans le mot de passe !
Il n'y a pas encore de tri sur les livres par auteur ou par cat�gorie !