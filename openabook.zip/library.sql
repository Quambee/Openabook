-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 31 Octobre 2017 à 11:26
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `library`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`email`, `password`, `name`) VALUES
('mickael.zimmermann@gmail.com', '$2y$11$37dad804ff0b0fb09cc09O3ED7amA9ouYpicSqdYdxvzvrHs9ew42', 'Mickael');

-- --------------------------------------------------------

--
-- Structure de la table `authors`
--

CREATE TABLE `authors` (
  `authorId` int(11) NOT NULL,
  `authorName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `authors`
--

INSERT INTO `authors` (`authorId`, `authorName`) VALUES
(2, 'Jules Verne'),
(4, 'Ken Follett'),
(5, 'Stephen King'),
(6, 'J.K.Rowling'),
(7, 'Dan Browne'),
(9, 'Fred Vargas'),
(10, 'Mary Higgins Clark'),
(11, 'Maxime Chattam');

-- --------------------------------------------------------

--
-- Structure de la table `books`
--

CREATE TABLE `books` (
  `bookId` int(11) NOT NULL,
  `bookName` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Disponible',
  `category_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `books`
--

INSERT INTO `books` (`bookId`, `bookName`, `status`, `category_id`, `author_id`) VALUES
(2, 'Les Piliers de la Terre', 'Disonible', 11, 4),
(3, '20 Mille lieues sous les mers', 'Disponible', 9, 2),
(5, 'Tour du monde en 80 jours', 'Disponible', 9, 2),
(6, 'Voyage au centre de la Terre', 'Disponible', 9, 2),
(7, 'De la Terre à la Lune', 'Disponible', 9, 2),
(8, 'Les contes de Beedle le barde', 'Disponible', 9, 6),
(9, 'La bibliothèque de Poudlard', 'Disponible', 9, 6),
(10, 'Les animaux fantastiques', 'Disponible', 9, 6),
(11, 'Harry Potter et la Coupe de feu', 'Indisponible', 9, 6),
(12, 'Charlie', 'Disponible', 10, 5),
(13, 'Coeurs perdus en Atlantide', 'Disponible', 10, 5),
(14, 'Ca I', 'Indisponible', 10, 5),
(15, 'Ca II', 'Indisponible', 10, 5),
(16, 'Une colonne de feu', 'Disponible', 11, 4),
(17, 'Un monde sans fin', 'Disponible', 11, 4),
(18, 'Quand sort la recluse', 'Disponible', 12, 9),
(20, 'L\'Affaire Cendrillon', 'Disponible', 12, 10),
(21, 'La mariée était en blanc', 'Disponible', 12, 10),
(22, 'L\'homme aux cercles bleus', 'Disponible', 12, 9),
(23, 'Temps glaciaires', 'Disponible', 12, 9),
(24, 'L\'appel du néant', 'Disponible', 17, 11),
(25, 'Carnages', 'Disponible', 18, 11),
(26, 'Que ta volonté soit faite', 'Disponible', 18, 11),
(27, 'Que ta volonté soit faite', 'Disponible', 18, 11);

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `categoryId` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`categoryId`, `categoryName`) VALUES
(9, 'Fantastique'),
(10, 'Science-fiction'),
(11, 'Historique'),
(12, 'Policier'),
(15, 'Bande-dessinée'),
(17, 'Polar'),
(18, 'Thriller');

-- --------------------------------------------------------

--
-- Structure de la table `loans`
--

CREATE TABLE `loans` (
  `loanId` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `loanDate` date DEFAULT NULL,
  `returnDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `loans`
--

INSERT INTO `loans` (`loanId`, `book_id`, `student_id`, `loanDate`, `returnDate`) VALUES
(22, 14, 11, '2017-10-31', '2017-11-20'),
(23, 15, 12, '2017-10-31', '2017-11-20'),
(24, 11, 12, '2017-10-31', '2017-11-20');

-- --------------------------------------------------------

--
-- Structure de la table `students`
--

CREATE TABLE `students` (
  `studentId` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `birthDate` date NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `students`
--

INSERT INTO `students` (`studentId`, `firstName`, `lastName`, `birthDate`, `phone`, `email`, `password`) VALUES
(1, 'Mickael', 'Zimmermann', '1986-03-08', '0632506631', 'mickael.zimmermann@gmail.com', '$2y$11$b4a927c124c36be398806OUA8HyvuXkb99K0yycVTeL556EuwjDcG'),
(11, 'Benoit', 'Petit', '1987-03-03', '0902038389', 'benoit.petit@gmail.com', '$2y$11$e949d736e74c47d7f980de.KqivjalPid9KXXYe4dIAwj9CZgp9Ji'),
(12, 'Antoine', 'Perrin', '2002-03-15', '0938207473', 'antoine.perrin@gmail.com', '$2y$11$122efbf7f7502d30087cfu/b1EF0vpD2gbYrO.Vv.od6wQB48kc1i');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`authorId`);

--
-- Index pour la table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`bookId`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `author_id` (`author_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categoryId`);

--
-- Index pour la table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`loanId`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Index pour la table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentId`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `authors`
--
ALTER TABLE `authors`
  MODIFY `authorId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `books`
--
ALTER TABLE `books`
  MODIFY `bookId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `categoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT pour la table `loans`
--
ALTER TABLE `loans`
  MODIFY `loanId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT pour la table `students`
--
ALTER TABLE `students`
  MODIFY `studentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`categoryId`),
  ADD CONSTRAINT `books_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `authors` (`authorId`);

--
-- Contraintes pour la table `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`bookId`),
  ADD CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`studentId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
