<?php


class UserSession
{
    protected $session;

	public function __construct()
	{
		$this->session = new Session();
	}

    public function createUser($studentId, $firstName, $lastName)
    {
        $this->session->set('user', [
            'studentId'    => $studentId,
            'firstName' => $firstName,
            'lastName'  => $lastName
        ]);

    }

    public function createAdmin($name)
    {
      $this->session->set('admin', [
        'name' => $name
      ]);
    }

    public function destroy()
    {
        $this->session->destroy();
    }

    public function getEmail()
    {
        if($this->isAuthenticated() == false)
        {
            return null;
        }

        return $this->session->get('user')['email'];
    }

    public function getFirstName()
    {
        if($this->userIsAuthenticated() == false)
        {
            return null;
        }

        return $this->session->get('user')['firstName'];
    }

    public function getFullName()
    {
        if($this->userIsAuthenticated() == false)
        {
            return null;
        }

        return $this->getFirstName().' '.$this->getLastName();
    }

    public function getLastName()
    {
        if($this->userIsAuthenticated() == false)
        {
            return null;
        }

        return $this->session->get('user')['lastName'];
    }

    public function getStudentId()
    {
        if($this->isAuthenticated() == false)
        {
            return null;
        }

        return $this->session->get('user')['studentId'];
    }

	public function userIsAuthenticated()
	{
		if ($this->session->get('user') !== null) {
		    return true;
        }

		return false;
	}

  public function adminIsAuthenticated()
  {
    if($this->session->get('admin') !== null) {
      return true;
    }

    return false;
  }

  public function getName()
  {
    if($this->adminIsAuthenticated() == false)
    {
      return null;
    }

    return $this->session->get('admin')['name'];
  }
}
