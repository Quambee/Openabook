<?php

class AdminSession
{

  protected $session;

  public function __construct()
	{
		$this->session = new Session();
	}

  public function createAdmin($name)
  {
    $this->session->set('admin', [
      'name' => $name
    ]);
  }

  public function destroy()
  {
      $this->session->destroy();
  }

  public function getEmail()
  {
      if($this->isAuthenticated() == false)
      {
          return null;
      }

      return $this->session->get('admin')['email'];
  }

  public function getName()
  {
    if($this->isAuthenticated() == false)
    {
      return null;
    }

    return $this->session->get('admin')['name'];
  }

  public function adminIsAuthenticated()
  {
    if($this->session->get('admin') !== null) {
      return true;
    }

    return false;
  }

}
