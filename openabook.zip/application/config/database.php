<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=openaboocomicka.mysql.db;dbname=openaboocomicka';
$config['user'] = 'openaboocomicka';
$config['password'] = 'A1b2C3d4';
