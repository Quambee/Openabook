<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=localhost;dbname=library'; 
$config['user'] = ;
$config['password'] = ;
