'use strict';

/////////////////////////////////////////////////////////////////////////////////////////
// FONCTIONS                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////



/************ FONCTION DATE ************/

function setDays(month) {
  // On supprime les éléments <option> pour l'élément <select> des jours afin de pouvoir ajouter les prochains
  while(daySelect.firstChild){
    daySelect.removeChild(daySelect.firstChild);
  }

  // On crée une variable afin de contenir le nombre de jours à afficher
  var dayNum;

  // 31 ou 30 jours ?
  if(month === 'Janvier' | month === 'Mars' | month === 'Mai' | month === 'Juillet' | month === 'Août' | month === 'Octobre' | month === 'Décembre') {
    dayNum = 31;
  } else if(month === 'Avril' | month === 'Juin' | month === 'Septembre' | month === 'Novembre') {
    dayNum = 30;
  } else {
  // Si le mois est février, on calcule si l'année est bissextile
    var leapYear = yearSelect.value;
    (leapYear - 2016) % 4 === 0 ? dayNum = 29 : dayNum = 28;
  }

  // on ajoute le bon nombre de jours dans autant d'éléments <option> pour l'élément <select> pour la journée
  for(var i = 1; i <= dayNum; i++) {
    var option = document.createElement('option');
    option.textContent = i;
    daySelect.appendChild(option);
  }

  // Si le jour précédent a déjà été défini on utilise la valeur de ce jour pour daySelect afin d'éviter de 
  // réinitialiser le jour lorsqu'on change l'année
  if(previousDay) {
    daySelect.value = previousDay;

    // Si le jour précédent correspond au dernier jour d'un mois et que le mois sélectionné possède moins de jours (par 
    // exemple en février)
    if(daySelect.value === "") {
      daySelect.value = previousDay - 1;
    }

    if(daySelect.value === "") {
      daySelect.value = previousDay - 2;
    }

    if(daySelect.value === "") {
      daySelect.value = previousDay - 3;
    }
  }
}

function setYears() {
  // On obtient l'année courante
  var date = new Date();
  var currentYear = date.getFullYear();

  // On affiche l'année courante et les 100 années précédentes pour l'élément <select> destiné à stocker l'année
  for(var i = 0; i <= 100; i++) {
    var option = document.createElement('option');
    option.textContent = currentYear-i;
    yearSelect.appendChild(option);
  }
}




/////////////////////////////////////////////////////////////////////////////////////////
// CODE PRINCIPAL                                                                      //
/////////////////////////////////////////////////////////////////////////////////////////

var originalDate = document.querySelector('.originalDate');
var classicDate = document.querySelector('.classicDate');

var yearSelect = document.querySelector('#year');
var monthSelect = document.querySelector('#month');
var daySelect = document.querySelector('#day');

// On masque le sélecteur classique
classicDate.style.display = 'none';

// On teste si l'élément <input type="date"> se transforme en <input type="text">
var test = document.createElement('input');
test.type = "date";
// Si c'est le cas, cela signifie que l'élément n'est pas pris en charge et
if(test.type === 'text') {
  // On masque le sélecteur natif et on affiche le sélecteur avec les <select>
  originalDate.style.display = 'none';
  classicDate.style.display = 'flex';

  // On affiche les jours et les années de façon dynamique
  setDays(monthSelect.value);
  setYears(yearSelect.value);
}

// Lorsque la valeur du mois ou de l'année est modifiée on relance la fonction
yearSelect.onchange = function() {
  setDays(monthSelect.value);
}

monthSelect.onchange = function() {
  setDays(monthSelect.value);
}

// On conserve le jour sélectionné
var previousDay;

// On met à jour la journée utilisé précédemment
daySelect.onchange = function() {
  previousDay = daySelect.value;
}
