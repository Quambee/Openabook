'use strict';

/////////////////////////////////////////////////////////////////////////////////////////
// FONCTIONS                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////
function validation(event) {

	for(var i=0; i <= tabInput.length; i++)
	{
		if(tabInput[i].value == "") {
			event.preventDefault();
			missInput.textContent = "Veuillez remplir tous les champs";
			missInput.classList.add('red');
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////////
// CODE PRINCIPAL                                                                      //
/////////////////////////////////////////////////////////////////////////////////////////

var formValid = document.querySelector('.generalForm button');
var missInput = document.querySelector('.miss');
var tabInput = document.querySelectorAll('input[type="text"]');

if(formValid != null)
{
	formValid.addEventListener('click', validation);
}


