<?php

class LogadminController {

  public function httpGetMethod(Http $http, array $queryFields)
  {
    /*
     * Méthode appelée en cas de requête HTTP GET
     *
     * L'argument $http est un objet permettant de faire des redirections etc.
     * L'argument $queryFields contient l'équivalent de $_GET en PHP natif.
     */
        $userSession = new UserSession();
        if($userSession->userIsAuthenticated() == true)
        {
            $userSession->destroy();
            $http->redirectTo('/login/logadmin');
        }

        return [
            'flash' => new FlashBag()
        ];
  }

  public function httpPostMethod(Http $http, array $formFields)
  {
    /*
     * Méthode appelée en cas de requête HTTP POST
     *
     * L'argument $http est un objet permettant de faire des redirections etc.
     * L'argument $formFields contient l'équivalent de $_POST en PHP natif.
     */

     $login = new LoginModel();

     // Gestion des erreurs
     $errors = $this->validateForm($formFields);

     if(count($errors) > 0)
     {

      $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

       $http->redirectTo('/login/logadmin');

     } 

     else 
     {
       
       $admin = $login->getAdmin();

       $hash = new Hash();

       if($hash->check($formFields['password'], $admin[0]['password'])) {
         $admin_session = new UserSession();
         $admin_session->createAdmin($admin[0]['name']);

         $http->redirectTo('/admin');
       } 
       else 
       {
         $http->redirectTo('/login/logadmin');
       }
     }
  }

  public function validateForm($formFields)
    {
        $login = new LoginModel();
        $data_admin = $login->getAdmin();

        $errors = [];

        $number_error_mail = 0;
        $number_error_password = 0;

            if($data_admin[0]['email'] == strtolower(htmlentities($_POST['mail'])))
            {
                $number_error_mail = -1;
            }

            if(empty($_POST['password']))
            {
                $errors['password'] = "Erreur ! Pas de mot de passe saisi !";
            }
            else
            {
                $password = new Hash();

                if($password->check($_POST['password'], $data_admin[0]['password']))
                {
                    $number_error_password = -1;
                }
            }

        if($number_error_mail != -1)
        {
            $errors['email'] = "Erreur ! Email inconnu !";
        }

        if($number_error_password != -1)
        {
            $errors['password'] = "Erreur ! Le mot de passe ne correspond pas !";
        }

        return $errors;
    }

}
