<?php

class LoguserController {

  public function httpGetMethod(Http $http, array $queryFields)
  {

        $adminSession = new UserSession();
        if($adminSession->adminIsAuthenticated() == true)
        {
            $adminSession->destroy();
            $http->redirectTo('/login/loguser');
        }

        return [
            'flash' => new FlashBag()
        ];
  }

  public function httpPostMethod(Http $http, array $formFields)
  {


     $login = new LoginModel();

     // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
     $errors = $this->validateForm($formFields);

     if(count($errors) > 0)
     {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

       $http->redirectTo('/login/loguser');

     } 
     else 
     {
        // Création de la session "user"
        $user = $login->getUser($_POST['email']);
        $user_session = new UserSession();
        $user_session->createUser($user[0]['studentId'], $user[0]['firstName'], $user[0]['lastName']);

        $http->redirectTo('/user');

     }
  }

  public function validateForm($formFields)
    {
        $login = new LoginModel();
        $data_users = $login->getUsers();

        $errors = [];

        // Vérification si le mot de passe de cet "user" correspond, si le mail de cet "user" correspond ou s'il n'y a pas de champs saisi.
        $number_error_mail = 0;
        $number_error_password = 0;

        foreach($data_users as $data_user)
        {
            if($data_user['email'] == strtolower(htmlentities($_POST['email'])))
            {
                $number_error_mail = -1;
                $errors = [];
            }

            if($number_error_mail != -1)
            {
                $errors['email'] = "Erreur ! Email inconnu";
            }
        }


        if(empty($_POST['password']))
        {
            $errors['password'] = "Erreur ! Pas de mot de passe saisi !";
        }
        else
        {
            $password = new Hash();

            if($password->check(htmlentities($_POST['password']), $data_users[0]['password']))
            {
                $number_error_password = -1;
            }
        
        }

        if($number_error_password != -1)
        {
            $errors['password'] = "Erreur ! Le mot de passe ne correspond pas !";
        }

        return $errors;
    }

}