<?php

class LoguserController {

  public function httpGetMethod(Http $http, array $queryFields)
  {
    /*
     * Méthode appelée en cas de requête HTTP GET
     *
     * L'argument $http est un objet permettant de faire des redirections etc.
     * L'argument $queryFields contient l'équivalent de $_GET en PHP natif.
     */
        $adminSession = new UserSession();
        if($adminSession->adminIsAuthenticated() == true)
        {
            $adminSession->destroy();
            $http->redirectTo('/login/loguser');
        }

        return [
            'flash' => new FlashBag()
        ];
  }

  public function httpPostMethod(Http $http, array $formFields)
  {
    /*
     * Méthode appelée en cas de requête HTTP POST
     *
     * L'argument $http est un objet permettant de faire des redirections etc.
     * L'argument $formFields contient l'équivalent de $_POST en PHP natif.
     */

     $login = new LoginModel();

     // Gestion des erreurs
     $errors = $this->validateForm($formFields);

     if(count($errors) > 0)
     {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

       $http->redirectTo('/login/loguser');

     } 
     else 
     {
        $user = $login->getUser($_POST['email']);
        $user_session = new UserSession();
        $user_session->createUser($user[0]['studentId'], $user[0]['firstName'], $user[0]['lastName']);

        $http->redirectTo('/user');

     }
  }

  public function validateForm($formFields)
    {
        $login = new LoginModel();
        $data_users = $login->getUsers();

        $errors = [];

        $number_error_mail = 0;
        $number_error_password = 0;

        foreach($data_users as $data_user)
        {
            if($data_user['email'] == strtolower(htmlentities($_POST['email'])))
            {
                $number_error_mail = -1;
                $errors = [];
            }

            if($number_error_mail != -1)
            {
                $errors['email'] = "Erreur ! Email inconnu";
            }
        }


        if(empty($_POST['password']))
        {
            $errors['password'] = "Erreur ! Pas de mot de passe saisi !";
        }
        else
        {
            $password = new Hash();

            if($password->check(htmlentities($_POST['password']), $data_users[0]['password']))
            {
                $number_error_password = -1;
            }
        
        }

        if($number_error_password != -1)
        {
            $errors['password'] = "Erreur ! Le mot de passe ne correspond pas !";
        }

        return $errors;
    }

}