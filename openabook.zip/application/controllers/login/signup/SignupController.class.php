<?php

class SignupController
{


  public function httpGetMethod(Http $http, array $queryFields)
  {

    return [
            'flash' => new FlashBag()
        ];
  }

  public function httpPostMethod(Http $http, array $formFields)
      {
          // Gestion des erreurs
          $errors = $this->validateForm($formFields);

          if(count($errors) > 0)
          {

             $flash = new FlashBag();

             foreach($errors as $error)
             {
               $flash->add($error);
             }
              // S'il y a des erreurs je redirige vers la page d'inscription
              $http->redirectTo('/login/signup');
          }
          else
          {
              // Enregistrement de l'étudiant
              $first_name = htmlentities($_POST['firstName']);
              $last_name = htmlentities($_POST['lastName']);
              if(!empty($_POST['bday']))
              {
                $birth_date = $_POST['bday'];
              }
              else
              {
                $birth_date = $_POST['year'] . '-' . $_POST['month'] . '-' . $_POST['day'];
              }

              $phone = htmlentities($_POST['phone']);
              $mail = htmlentities($_POST['mail']);
              $password = new Hash();
              $hashed_password = $password->create(htmlentities($_POST['password']));

              $database = new Database();
              $database->executeSql("INSERT INTO students (firstName, lastName, birthDate, phone, email, password)
                                         VALUES (?, ?, ?, ?, ?, ?)", [
                                        $first_name, $last_name, $birth_date, $phone, $mail, $hashed_password
                                         ]);

              // Redirection vers la page de login
              $http->redirectTo('/login/loguser');

          }
      }

      public function validateForm($formFields)
      {
          $errors = [];
          if(empty($_POST['firstName']))
          {
              $errors['firstName'] = "Le nom est obligatoire !";
          }

          if(empty($_POST['lastName']))
          {
              $errors['lastName'] = "Le prénom est obligatoire !";
          }


          if(empty($_POST['mail']))
          {
              $errors['mail'] = "Le mail  est obligatoire !"; 
          }
          else
          {
            if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", htmlentities($_POST['mail'])))
            {
              $errors['email'] =  "Cet email n\'est pas valide, recommencez !";
            }

            $userModel = new LoginModel();
            $users = $userModel->getUsers();

            foreach($users as $user)
            {
              if($user['email'] == $_POST['mail'])
              {
                $errors['mail'] = "Cet email est déjà utilisé !";
              }
            }
          }

          if(isset($_POST['password']))
          {
            if (!preg_match('#^(?=.*[a-z])(?=.*[0-9]).{6,}$#', htmlentities($_POST['password']))) 
            {
              $errors['password'] = "Le mot de passe doit contenir au moins un chiffre, une minuscule et 6 chiffres de longueur minimum, pas de majuscule !";
            }

          }

          return $errors;

      }


}
