<?php

class ListbookController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
        $userSession = new UserSession();
        if($userSession->userIsAuthenticated() == false)
        {
            $http->redirectTo('/login/loguser');
        }

    $book = new BookModel();
    $category = new CategoryModel();
    $author = new AuthorModel();

    return [
      'books' => $book->getAll()
    ];
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }

}
