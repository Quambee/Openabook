<?php

class ListbookController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'élève est authentifié
    $userSession = new UserSession();
    if($userSession->userIsAuthenticated() == false)
    {
      $http->redirectTo('/login/loguser');
    }

    $book = new BookModel();
    $category = new CategoryModel();
    $author = new AuthorModel();

    // Vérification s'il y a un livre d'enregistré, sinon on envoie un petit message
    if(count($book->getAll()) == 0)
    {
      $flash = new FlashBag();
      $flash->add("Il n'y a pas de livres !");
      
      return [
        'flash' => $flash
      ];
    }
    else
    {
      return [
        'books' => $book->getAll(),
        'flash' => new FlashBag()
      ];
    }

  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }

}
