<?php

class LoanController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    $userSession = new UserSession();
    if($userSession->userIsAuthenticated() == false)
    {
        $http->redirectTo('/login/loguser');
    }

    $book = new BookModel();
    $category = new CategoryModel();
    $author = new AuthorModel();
    $loan = new LoanModel();

    if(isset($queryFields['loanbook']))
    {
      $book_id = $queryFields['loanbook'];
      $student_id = $queryFields['student'];
      $date = date('Y-m-d');
      $returnDate = date('Y-m-d', strtotime('+20 days'));


      $loan->insert($book_id, $student_id, $date, $returnDate);
      $book->loaned($book_id);
    }

     $http->redirectTo('/user/listbook');

  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }

}
