<?php

class UserController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
      // On vérifie si l'élève est authentifié pour empêcher l'accès si l'on n'est pas connecté ou si on est en "admin"
      $userSession = new UserSession();
      if($userSession->userIsAuthenticated() == false)
      {
          $http->redirectTo('/login/loguser');
      }

    }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }


}
