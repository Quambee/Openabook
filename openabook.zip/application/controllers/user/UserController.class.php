<?php

class UserController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
      $userSession = new UserSession();
      if($userSession->userIsAuthenticated() == false)
      {
          $http->redirectTo('/login/loguser');
      }

    }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }


}
