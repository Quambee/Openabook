<?php

class ReturnbookController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'élève est authentifié
    $userSession = new UserSession();
    if($userSession->userIsAuthenticated() == false)
    {
        $http->redirectTo('/login/loguser');
    }

    if(isset($queryFields['returnthisbook']))
    {
      $loan = new LoanModel();
      $book = new BookModel();
      $loan->delete($queryFields['returnthisbook']);
      $book->returned($queryFields['bookid']);
    }

    // Un petit message s'il n'y a pas de livre emprunté par l'élève
    $loan = new LoanModel();
    if(count($loan->getBooksToReturn($_SESSION['user']['studentId'])) == 0)
    {
      $flash = new FlashBag();
      $flash->add("Pas de livre à rendre.");

      return [
        'flash' => $flash
      ];
    }
    $category = new CategoryModel();
    $author = new AuthorModel();

    return [
      'loans' => $loan->getBooksToReturn($_SESSION['user']['studentId']),
      'flash' => new FlashBag()
    ];
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }


}
