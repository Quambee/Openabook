<?php

class ReturnbookController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
        $userSession = new UserSession();
        if($userSession->userIsAuthenticated() == false)
        {
            $http->redirectTo('/login/loguser');
        }
    /*return [
            'flash' => new FlashBag()
        ];*/

        if(isset($queryFields['returnthisbook']))
        {
          $loan = new LoanModel();
          $book = new BookModel();
          $loan->delete($queryFields['returnthisbook']);
          $book->returned($queryFields['bookid']);
        }

         $loan = new LoanModel();
         $category = new CategoryModel();
         $author = new AuthorModel();

    return [
      'loans' => $loan->getBooksToReturn($_SESSION['user']['studentId'])

      //'flash' => new FlashBag()
    ];
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }


}
