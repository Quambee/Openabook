<?php

class LogoutController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
    	// Destruction de la session en cours
        $user_session = new UserSession();
        $user_session->destroy();
        $http->redirectTo('/');
    }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }
}
