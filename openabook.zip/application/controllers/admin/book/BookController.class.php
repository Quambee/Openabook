<?php

class BookController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'admin est authentifié
    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    $book = new BookModel();
    $category = new CategoryModel();
    $author = new AuthorModel();

    // Vérification s'il y a un livre d'enregistré, sinon on envoie un petit message
    $books = $book->getAll();
    $count = count($books);

    if($count == 0)
    {
      $flash = new FlashBag();
      $flash->add("Il n'y a pas de livre !");
      
      return [
        'flash' => $flash
      ];
    }
    else
    {
      // On vérifie s'il y a une suppression d'un livre
      if(isset($queryFields['del']))
      { 
        if(count($book->getThisBookLoaned($queryFields['del']) == 0))
        {
          $flash = new FlashBag();
          $flash->add("Impossible de supprimer un livre déjà emprunté.");
          return [
            'flash' => $flash,
            'books' => $book->getAll()
          ];
        }
        else
        {
           $book->delete($queryFields['del']);
        }
       
      }
      // On vérifie s'il y a une demande de modification du livre concerné
      if(isset($queryFields['edit']))
      {
        return [
          'bookEdit' => $book->getOne($queryFields['edit']),
          'categories' => $category->getAll(),
          'authors' => $author->getAll(),
          'flash' => new FlashBag()
        ];
      }

      return [
        'books' => $book->getAll(),
        'flash' => new FlashBag()
      ];
    }
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

      // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
      $errors = $this->validateForm($formFields);

      if(count($errors) > 0)
      {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

        $http->redirectTo('/admin/book');
      }
      else
      {
        // Enregistrement d'un livre'
        $bookName = htmlentities($_POST['bookName']);
        $bookId = htmlentities($_POST['bookId']);
        $categoryId = $_POST['category_id'];
        $authorId = $_POST['author_id'];

        $book = new BookModel();
        $book->update($bookName, $bookId, $categoryId, $authorId);

        $http->redirectTo('/admin/book');
      }
  }

  public function validateForm($formFields)
  {
    $errors = [];
    if(empty(htmlentities($_POST['bookName'])))
    {
      $errors['bookName'] = "Le nom du livre est obligatoire !";

    }

    return $errors;

    }
}
