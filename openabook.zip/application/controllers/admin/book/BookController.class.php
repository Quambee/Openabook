<?php

class BookController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {

    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    $book = new BookModel();
    $category = new CategoryModel();
    $author = new AuthorModel();

    if(isset($queryFields['del']))
    {
      $book->delete($queryFields['del']);
    }

    if(isset($queryFields['edit']))
    {
      return [
        'bookEdit' => $book->getOne($queryFields['edit']),
        'categories' => $category->getAll(),
        'authors' => $author->getAll(),
        'flash' => new FlashBag()
      ];
    }

    return [
      'books' => $book->getAll(),
      'flash' => new FlashBag()
    ];
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

      // Gestion des erreurs
      $errors = $this->validateForm($formFields);

      if(count($errors) > 0)
      {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

        $http->redirectTo('/admin/book');
      }
      else
      {
        // Enregistrement d'un livre'
        $bookName = htmlentities($_POST['bookName']);
        $bookId = htmlentities($_POST['bookId']);
        $categoryId = $_POST['category_id'];
        $authorId = $_POST['author_id'];

        $book = new BookModel();
        $book->update($bookName, $bookId, $categoryId, $authorId);

        $http->redirectTo('/admin/book');
      }
  }

  public function validateForm($formFields)
  {
    $errors = [];
    if(empty(htmlentities($_POST['bookName'])))
    {
      $errors['bookName'] = "Le nom du livre est obligatoire !";

    }

    return $errors;

    }
}
