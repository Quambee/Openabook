<?php

class AddbookController
{

  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'admin est authentifié
    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    // On renvoie les auteurs et les catégories pour pouvoir ajouter un livre
    $author = new AuthorModel();
    $category = new CategoryModel();

    return [
      'authors' => $author->getAll(),
      'categories' => $category->getAll(),
      'flash' => new FlashBag()
    ];

  }

  public function httpPostMethod(Http $http, array $formFields)
  {
      // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
      $errors = $this->validateForm($formFields);

      if(count($errors) > 0)
      {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

        $http->redirectTo('/admin/category/addbook');
      }
      else
      {
        // Enregistrement du livre
        $bookName = htmlentities($_POST['bookName']);

        $category_id = $_POST['category_id'];
        $author_id = $_POST['author_id'];

        $book = new BookModel();

        $book->insert($bookName, $category_id, $author_id);

        $http->redirectTo('/admin/book');
      }
  }

  public function validateForm($formFields)
  {
    $errors = [];
    if(empty(htmlentities($_POST['bookName'])))
    {
      $errors['bookName'] = "Le nom du livre est obligatoire !";


    } 

    return $errors;

  }




}
