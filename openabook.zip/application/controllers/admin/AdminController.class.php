<?php

class AdminController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
        // On vérifie si l'admin est authentifié pour empêcher l'accès si l'on n'est pas connecté ou si on est en "user"
        $adminSession = new AdminSession();
        if($adminSession->adminIsAuthenticated() == false)
        {
            $http->redirectTo('/login/logadmin');
        }

  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }


}
