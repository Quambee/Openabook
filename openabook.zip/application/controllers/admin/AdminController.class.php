<?php

class AdminController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {

        $adminSession = new AdminSession();
        if($adminSession->adminIsAuthenticated() == false)
        {
            $http->redirectTo('/login/logadmin');
        }

  }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }


}
