<?php

class AuthorController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {

    // On vérifie si l'admin est authentifié
    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    $author = new AuthorModel();
    $book = new BookModel();

    // Vérification s'il y a un auteur d'enregistré, sinon on envoie un petit message
    $authors = $author->getAll();
    $count = count($authors);
    if($count == 0)
    {
      $flash = new FlashBag();
      $flash->add("Il n'y a pas d'auteurs !");
      
      return [
        'flash' => $flash
      ];
    }
    else
    {
      // On vérifie s'il y a une suppression d'un auteur
      // Puis on vérifie si le livre utilise déjà cet auteur, si oui impossible de supprimer
      if(isset($queryFields['del']))
      {
        $books = $book->getBooksThisAuthor($queryFields['del']);
        $count = count($books);
        if($count != 0)
        {
          $flash = new FlashBag();
          $flash->add("Impossible de supprimer, au moins un livre utilise cet auteur.");
          $http->redirectTo('/admin/author');
        }
        else
        {
          $author->delete($queryFields['del']);
        }
        
      }

      // On vérifie s'il y a une demande de modification de l'auteur concerné
      if(isset($queryFields['edit']))
      {
        return [
          'author_edit' => $author->getOne($queryFields['edit']),
          'flash' => new FlashBag()
        ];
      }

      return [
        'authors' => $author->getAll(),
        'flash' => new FlashBag()
      ];
    }
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

      // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
      $errors = $this->validateForm($formFields);

      if(count($errors) > 0)
      {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

        $http->redirectTo('/admin/author');
      }
      else
      {
        // Enregistrement de l' auteur dans le cas de la modification de l'auteur
          $authorName = htmlentities($_POST['authorName']);
          $authorId = htmlentities($_POST['authorId']);

          $author = new AuthorModel();
          $author->update($authorName, $authorId);

          $http->redirectTo('/admin/author');

      }
  }

  public function validateForm($formFields)
  {
    $errors = [];
    if(empty(htmlentities($_POST['authorName'])))
    {
      $errors['authorName'] = "Le nom de l\'auteur est obligatoire !";
    }

    return $errors;
  }
}
