<?php

class AuthorController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {

    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    $author = new AuthorModel();

    if(isset($queryFields['del']))
    {
      $author->delete($queryFields['del']);
    }

    if(isset($queryFields['edit']))
    {
      return [
        'author_edit' => $author->getOne($queryFields['edit']),
        'flash' => new FlashBag()
      ];
    }

    return [
      'authors' => $author->getAll(),
      'flash' => new FlashBag()
    ];
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

      // Gestion des erreurs
      $errors = $this->validateForm($formFields);

      if(count($errors) > 0)
      {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

        $http->redirectTo('/admin/author');
      }
      else
      {
        // Enregistrement de l' auteur'
          $authorName = htmlentities($_POST['authorName']);
          $authorId = htmlentities($_POST['authorId']);

          $author = new AuthorModel();
          $author->update($authorName, $authorId);

          $http->redirectTo('/admin/author');

      }
  }

  public function validateForm($formFields)
  {
    $errors = [];
    if(empty(htmlentities($_POST['authorName'])))
    {
      $errors['authorName'] = "Le nom de l\'auteur est obligatoire !";
    }

    return $errors;
  }
}
