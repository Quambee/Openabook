<?php

class AddauthorController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'admin est authentifié
    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    return [
            'flash' => new FlashBag()
        ];
  }


    public function httpPostMethod(Http $http, array $formFields)
    {
        // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
        $errors = $this->validateForm($formFields);

        if(count($errors) > 0)
        {
          $flash = new FlashBag();

          foreach($errors as $error)
          {
            $flash->add($error);
          }

          $http->redirectTo('/admin/author/addauthor');
        }
        else
        {
          // Enregistrement de l'auteur
          $authorName = htmlentities($_POST['authorName']);

          $author = new AuthorModel();
          $author->insert($authorName);

          $http->redirectTo('/admin/author');
        }
    }

    public function validateForm($formFields)
    {
      $errors = [];
      if(empty(htmlentities($_POST['authorName'])))
      {
        $errors['authorName'] = "Le nom de l\'auteur est obligatoire !";
      }

      return $errors;
    }
}
