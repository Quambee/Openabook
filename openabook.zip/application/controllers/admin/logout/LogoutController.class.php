<?php

class LogoutController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
        $user_session = new UserSession();
        $user_session->destroy();
        $http->redirectTo('/');
    }

    public function httpPostMethod(Http $http, array $formFields)
    {

    }
}
