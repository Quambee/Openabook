<?php

class CategoryController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'admin est authentifié
    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    $category = new CategoryModel();
    $book = new BookModel();

    // Vérification s'il y a une catégorie d'enregistrée, sinon on envoie un petit message
    $categories = $category->getAll();
    $count = count($categories);
    if($count == 0)
    {
      $flash = new FlashBag();
      $flash->add("Il n'y a pas de catégorie !");
      
      return [
        'flash' => $flash
      ]; 
    }
    else
    {
      // On vérifie s'il y a une suppression d'une catégorie
      // Puis on vérifie si le livre utilise déjà cette catégorie, si oui impossible de supprimer
      if(isset($queryFields['del']))
      {
        $books = $book->getBooksThisCategory($queryFields['del']);
        $count = count($books);
        if($count != 0)
        {
          $flash = new FlashBag();
          $flash->add("Impossible de supprimer, au moins un livre utilise cette catégorie.");
          $http->redirectTo('/admin/category');
        }
        else
        {
          $category->delete($queryFields['del']);
        }
        
      }

      // On vérifie s'il y a une demande de modification de la catégorie concernée
      if(isset($queryFields['edit']))
      {
        return [
          'category_edit' => $category->getOne($queryFields['edit']),
          'flash' => new FlashBag()
        ];
      }

      return [
        'categories' => $category->getAll(),
        'flash' => new FlashBag()
      ];
    }
  }

    public function httpPostMethod(Http $http, array $formFields)
    {

      // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
      $errors = $this->validateForm($formFields);

      if(count($errors) > 0)
      {
        $flash = new FlashBag();

        foreach($errors as $error)
        {
          $flash->add($error);
        }

        $http->redirectTo('/admin/category');
      }
      else
      {
        // Enregistrement de la catégorie
        $categoryName = htmlentities($_POST['categoryName']);
        $categoryId = htmlentities($_POST['categoryId']);

        $category = new CategoryModel();
        $category->update($categoryName, $categoryId);

        $http->redirectTo('/admin/category');
      }
  }

  public function validateForm($formFields)
  {
    $errors = [];
    if(empty(htmlentities($_POST['categoryName'])))
    {
      $errors['categoryName'] = "Le nom de la catégorie est obligatoire !";
    }

    return $errors;
    }
}
