<?php

class AddcategoryController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    // On vérifie si l'admin est authentifié
    $adminSession = new UserSession();
    if($adminSession->adminIsAuthenticated() == false)
    {
        $http->redirectTo('/login/logadmin');
    }

    return [
            'flash' => new FlashBag()
        ];
  }

    public function httpPostMethod(Http $http, array $formFields)
    {
        // S'il y a des erreurs dans le formulaire, on revnoie la page avec un message d'erreurs
        $errors = $this->validateForm($formFields);

        if(count($errors) > 0)
        {
          $flash = new FlashBag();

          foreach($errors as $error)
          {
            $flash->add($error);
          }

          $http->redirectTo('/admin/category/addcategory');
        }
        else
        {
          // Enregistrement de la catégorie
          $categoryName = htmlentities($_POST['categoryName']);

          $category = new CategoryModel();

          $category->insert($categoryName);
          
          $http->redirectTo('/admin/category');
        }
    }

    public function validateForm($formFields)
    {
      $errors = [];
      if(empty(htmlentities($_POST['categoryName'])))
      {
        $errors['categoryName'] = "Le nom de la catégorie est obligatoire !";
      }

      return $errors;
    }
}
