<?php

class CategoryModel
{

  public function getAll()
  {
    $db = new Database();

    return $db->query('SELECT * 
                       FROM categories
                       ORDER BY categoryName ASC');
  }

  public function getOne($category_id)
  {
    $db = new Database();

    return $db->queryOne('SELECT *
                          FROM categories
                          WHERE categoryId = ?', [
                            $category_id
                          ]);
  }

  public function insert($categoryName)
  {
    $db = new Database();
    return $db->executeSql("INSERT INTO categories (categoryName)
                              VALUES (?)", [
                                $categoryName
                              ]);
  }

  public function delete($category_id)
  {
    $db = new Database();

    return $db->executeSql('DELETE FROM categories
                            WHERE categoryId = ?',
                            [$category_id]
                          );
  }

  public function update($category_name, $category_id)
  {
    $db = new Database();

    return $db->executeSql('UPDATE categories
                            SET categoryName = ?
                            WHERE categoryId = ?',
                            [$category_name, $category_id]
                          );
  }

}
