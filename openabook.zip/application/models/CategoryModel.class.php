<?php

class CategoryModel
{

  // Fonction qui renvoie toutes les catégories
  public function getAll()
  {
    $db = new Database();

    return $db->query('SELECT * 
                       FROM categories
                       ORDER BY categoryName ASC');
  }

  // Fonction qui renvoie une catégorie en particulier
  public function getOne($category_id)
  {
    $db = new Database();

    return $db->queryOne('SELECT *
                          FROM categories
                          WHERE categoryId = ?', [
                            $category_id
                          ]);
  }

  // Fonction d'insertion d'une catégorie
  public function insert($categoryName)
  {
    $db = new Database();
    return $db->executeSql("INSERT INTO categories (categoryName)
                              VALUES (?)", [
                                $categoryName
                              ]);
  }

  // Fonction de suppression d'une catégorie
  public function delete($category_id)
  {
    $db = new Database();

    return $db->executeSql('DELETE FROM categories
                            WHERE categoryId = ?',
                            [$category_id]
                          );
  }

  // Fonction de modification d'une catégorie
  public function update($category_name, $category_id)
  {
    $db = new Database();

    return $db->executeSql('UPDATE categories
                            SET categoryName = ?
                            WHERE categoryId = ?',
                            [$category_name, $category_id]
                          );
  }

}
