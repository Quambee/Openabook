<?php

class BookModel
{

  // Fonction qui renvoie tous les livres
    public function getAll()
    {
      $db = new Database();

      return $db->query('SELECT * 
                         FROM books
                         ORDER BY bookName ASC');
    }

    // FOnction qui renvoie un livre en particulier
    public function getOne($book_id)
    {
      $db = new Database();

      return $db->queryOne('SELECT *
                            FROM books
                            WHERE bookId = ?',[
                            $book_id
                          ]);
    }

    // Insertion d'un livre
    public function insert($book_name, $category_id, $author_id)
    {
      $db = new Database();
      return $db->executeSql("INSERT INTO books (bookName, category_id, author_id)
                              VALUES (?, ?, ?)",[
                                $book_name, $category_id, $author_id
                              ]);
    }

    // Suppression d'un livre
    public function delete($book_id)
    {
      $db = new Database();

      return $db->executeSql('DELETE FROM books
                              WHERE bookId = ?',
                              [$book_id]
                            );
    }

    // Fonction de modification d'un livre
    public function update($book_id, $book_name, $category_id, $author_id)
    {
      $db = new Database();

      return $db->executeSql('UPDATE books
                              SET bookName = ?, category_id = ?, author_id = ?
                              WHERE bookId = ?',[
                                $book_name, $category_id, $author_id, $book_id
                            ]);
    }

    // Fonction qui modifie le statut du livre pour indiquer qu'il a été emprunté par un élève
    public function loaned($book_id)
    {
      $db = new Database();

      return $db->executeSql('UPDATE books
                              SET status = "Indisponible"
                              WHERE bookId = ?', [
                                $book_id
                            ]);
    }

    // Fonction qui modifie le status d'un livre pour indiquer qu'il a été rendu
    public function returned($book_id)
    {
      $db = new Database();

      return $db->executeSql('UPDATE books
                              SET status = "Disponible"
                              WHERE bookId = ?', [
                                $book_id
                              ]);
    }

    // FOnction qui renvoie tous les livres d'un auteur précis
    public function getBooksThisAuthor($author_id)
    {
      $db = new Database();

      return $db->query('SELECT * 
                         FROM books
                         WHERE author_id = ?', [
                          $author_id
                        ]);
    }

    // fonction qui renvoie tous les livres d'une catégorie précise
    public function getBooksThisCategory($category_id)
    {
      $db = new Database();

      return $db->query('SELECT *
                         FROM books
                         WHERE category_id = ?', [
                          $category_id
                        ]);
    }

    // Fonction qui renvoie un livre donné s'il est en statut "Indisponible"
    public function getThisBookLoaned($book_id)
    {
      $db = new Database();

      return $db->queryOne('SELECT *
                            FROM books
                            WHERE status = "Indisponible" AND bookId = ?', [
                              $book_id 
                          ]);
    }

}
