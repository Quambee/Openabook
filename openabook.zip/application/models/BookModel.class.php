<?php

class BookModel
{

    public function getAll()
    {
      $db = new Database();

      return $db->query('SELECT * 
                         FROM books
                         ORDER BY bookName ASC');
    }

    public function getOne($book_id)
    {
      $db = new Database();

      return $db->queryOne('SELECT *
                            FROM books
                            WHERE bookId = ?',[
                            $book_id
                          ]);
    }

    


    public function insert($book_name, $category_id, $author_id)
    {
      $db = new Database();
      return $db->executeSql("INSERT INTO books (bookName, category_id, author_id)
                              VALUES (?, ?, ?)",[
                                $book_name, $category_id, $author_id
                              ]);
    }


    public function delete($book_id)
    {
      $db = new Database();

      return $db->executeSql('DELETE FROM books
                              WHERE bookId = ?',
                              [$book_id]
                            );
    }


    public function update($book_id, $book_name, $category_id, $author_id)
    {
      $db = new Database();

      return $db->executeSql('UPDATE books
                              SET bookName = ?, category_id = ?, author_id = ?
                              WHERE bookId = ?',[
                                $book_name, $category_id, $author_id, $book_id
                            ]);
    }

    public function loaned($book_id)
    {
      $db = new Database();

      return $db->executeSql('UPDATE books
                              SET status = "Indisponible"
                              WHERE bookId = ?', [
                                $book_id
                            ]);
    }

    public function returned($book_id)
    {
      $db = new Database();

      return $db->executeSql('UPDATE books
                              SET status = "Disponible"
                              WHERE bookId = ?', [
                                $book_id
                              ]);
    }


}
