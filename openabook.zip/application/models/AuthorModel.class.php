<?php

class AuthorModel
{

  public function getAll()
  {
    $db = new Database();

    return $db->query('SELECT * 
                       FROM authors
                       ORDER BY authorName ASC');
  }

  public function getOne($author_id)
  {
    $db = new Database();

    return $db->queryOne('SELECT *
                          FROM authors
                          WHERE authorId = ?', [
                            $author_id
                          ]);
  }

  public function insert($authorName)
  {
    $db = new Database();
    return $db->executeSql("INSERT INTO authors (authorName)
                              VALUES (?)", [
                                $authorName
                            ]);
  }

  public function delete($author_id)
  {
    $db = new Database();

    return $db->executeSql('DELETE FROM authors
                            WHERE authorId = ?',
                            [$author_id]
                          );
  }

  public function update($author_name, $author_id)
  {
    $db = new Database();

    return $db->executeSql('UPDATE authors
                            SET authorName = ?
                            WHERE authorId = ?',
                            [$author_name, $author_id]
                          );
  }

}
