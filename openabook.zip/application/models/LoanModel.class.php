<?php

class LoanModel
{
    // Fonction qui renvoie tous les prêts
    public function getAll()
    {
      $db = new Database();

      return $db->query('SELECT * FROM loans');
    }

    // Fonction qui renvoie un prêt en particulier
    public function getOne($loan_id)
    {
      $db = new Database();

      return $db->queryOne('SELECT *
                            FROM loans
                            WHERE loanId = ?',[
                            $loan_id
                          ]);
    }

    // Fonction d'insertion d'un prêt
    public function insert($book_id, $student_id, $loan_date, $return_date)
    {
      $db = new Database();
      return $db->executeSql("INSERT INTO loans (book_id, student_id, loanDate, returnDate)
                              VALUES (?, ?, ?, ?)", [
                                $book_id, $student_id, $loan_date, $return_date
                              ]);
    }

    // Fonction de suppression d'un prêt
    public function delete($loan_id)
    {
      $db = new Database();

      return $db->executeSql('DELETE FROM loans
                              WHERE loanId = ?',
                              [$loan_id]
                            );
    }

    // Fonction qui renvoie les livres qui ont été empruntés par cet élève
    public function getBooksToReturn($student_id)
    {
      $db = new Database();
      return $db->query("SELECT *
                         FROM loans
                         INNER JOIN books ON books.bookId = loans.book_id
                         WHERE loans.student_id = ?", [
                          $student_id
                        ]);
    }

}
