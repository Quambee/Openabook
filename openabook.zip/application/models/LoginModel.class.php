<?php

class LoginModel {

    // Fonction qui renvoie les informations de l'admin
    public function getAdmin() 
    {
      $db = new Database();
      return $db->query('SELECT email, password, name FROM admin');
    }

    // Fonction qui renvoie tous les élèves
    public function getUsers()
    {
    	$db = new Database();
    	return $db->query('SELECT * 
    					   FROM students
    					   ');
    }

    // FOnction qui renvoie un élève en particulier
    public function getUser($email)
    {
        $db = new Database();
        return $db->query('SELECT * 
                           FROM students
                           WHERE email = ?', [
                            $email
                          ]);
    }
}
