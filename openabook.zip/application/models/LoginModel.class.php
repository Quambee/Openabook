<?php

class LoginModel {

    public function getAdmin() 
    {
      $db = new Database();
      return $db->query('SELECT email, password, name FROM admin');
    }

    public function getUsers()
    {
    	$db = new Database();
    	return $db->query('SELECT * 
    					   FROM students
    					   ');
    }

    public function getUser($email)
    {
        $db = new Database();
        return $db->query('SELECT * 
                           FROM students
                           WHERE email = ?', [
                            $email
                          ]);
    }
}
